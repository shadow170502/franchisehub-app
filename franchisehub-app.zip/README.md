# FranchiseHub App
Starter project using Next.js + Supabase.