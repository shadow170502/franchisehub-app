'use client';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default function LoginPage() {
  return (
    <div>
      <h1>Masuk FranchiseHub</h1>
      <button onClick={async () => {
        await supabase.auth.signInWithOAuth({ provider: 'google' });
      }}>Masuk dengan Google</button>
    </div>
  );
}
