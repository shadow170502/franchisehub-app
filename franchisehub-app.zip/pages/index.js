export default function Home() {
  return (
    <main>
      <h1>FranchiseHub App</h1>
      <p>Starter project using Next.js + Supabase</p>
    </main>
  );
}
